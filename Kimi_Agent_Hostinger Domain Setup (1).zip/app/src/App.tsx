import { useEffect, useState, useRef } from 'react';
import './App.css';
import { 
  Phone, 
  Mail, 
  MessageCircle, 
  Instagram, 
  Gamepad2, 
  Image, 
  Palette, 
  Layout,
  User,
  Star,
  ChevronRight,
  ShoppingCart,
  Menu,
  X,
  CreditCard
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

// Category data
const categories = [
  { id: '2d', name: '2D Full Body', icon: User, image: '/2d-1.jpg' },
  { id: '3d', name: '3D Models', icon: Gamepad2, image: '/3d-1.jpg' },
  { id: 'covers', name: 'Covers & Banners', icon: Layout, image: '/cover-1.jpg' },
  { id: 'logos', name: 'Logos', icon: Palette, image: '/logo-1.jpg' },
  { id: 'pfp', name: 'Profile Pictures', icon: Image, image: '/pfp-1.jpg' },
];

// Products data
const products2D = [
  { id: 1, name: 'Phoenix Warrior', category: '2D Full Body', image: '/2d-1.jpg', price: 'Contact for Price' },
  { id: 2, name: 'Dark Knightess', category: '2D Full Body', image: '/2d-2.jpg', price: 'Contact for Price' },
  { id: 3, name: 'Shadow Ninja', category: '2D Full Body', image: '/2d-3.jpg', price: 'Contact for Price' },
  { id: 4, name: 'Celestial Mage', category: '2D Full Body', image: '/2d-4.jpg', price: 'Contact for Price' },
  { id: 5, name: 'Samurai Lord', category: '2D Full Body', image: '/2d-5.jpg', price: 'Contact for Price' },
];

const products3D = [
  { id: 1, name: 'Cyber Soldier', category: '3D Models', image: '/3d-1.jpg', price: 'Contact for Price' },
  { id: 2, name: 'Chibi Bot', category: '3D Models', image: '/3d-2.jpg', price: 'Contact for Price' },
  { id: 3, name: 'Emerald Dragon', category: '3D Models', image: '/3d-3.jpg', price: 'Contact for Price' },
  { id: 4, name: 'Neon Speedster', category: '3D Models', image: '/3d-4.jpg', price: 'Contact for Price' },
  { id: 5, name: 'Cyborg Assassin', category: '3D Models', image: '/3d-5.jpg', price: 'Contact for Price' },
];

const productsCovers = [
  { id: 1, name: 'Cyberpunk City Banner', category: 'Covers & Banners', image: '/cover-1.jpg', price: 'Contact for Price' },
  { id: 2, name: 'Epic Battle Header', category: 'Covers & Banners', image: '/cover-2.jpg', price: 'Contact for Price' },
  { id: 3, name: 'Liquid Flow Banner', category: 'Covers & Banners', image: '/cover-3.jpg', price: 'Contact for Price' },
  { id: 4, name: 'Esports Gaming Banner', category: 'Covers & Banners', image: '/cover-4.jpg', price: 'Contact for Price' },
  { id: 5, name: 'Fantasy Forest Header', category: 'Covers & Banners', image: '/cover-5.jpg', price: 'Contact for Price' },
];

const productsLogos = [
  { id: 1, name: 'Alpha Fang Esports', category: 'Logos', image: '/logo-1.jpg', price: 'Contact for Price' },
  { id: 2, name: 'Team Nova Phoenix', category: 'Logos', image: '/logo-2.jpg', price: 'Contact for Price' },
  { id: 3, name: 'ShadowByte Gaming', category: 'Logos', image: '/logo-3.jpg', price: 'Contact for Price' },
  { id: 4, name: 'Golden Roar Guild', category: 'Logos', image: '/logo-4.jpg', price: 'Contact for Price' },
  { id: 5, name: 'Meow Stream Kawaii', category: 'Logos', image: '/logo-5.jpg', price: 'Contact for Price' },
];

const productsPFP = [
  { id: 1, name: 'Cyberpunk Girl', category: 'Profile Pictures', image: '/pfp-1.jpg', price: 'Contact for Price' },
  { id: 2, name: 'Mystic Mage', category: 'Profile Pictures', image: '/pfp-2.jpg', price: 'Contact for Price' },
  { id: 3, name: 'Kawaii Gamer', category: 'Profile Pictures', image: '/pfp-3.jpg', price: 'Contact for Price' },
  { id: 4, name: 'Fire Knight', category: 'Profile Pictures', image: '/pfp-4.jpg', price: 'Contact for Price' },
  { id: 5, name: 'Star Princess', category: 'Profile Pictures', image: '/pfp-5.jpg', price: 'Contact for Price' },
];

// Testimonials data
const testimonials = [
  {
    id: 1,
    name: 'Michael R.',
    image: '/customer-1.jpg',
    rating: 5,
    text: 'Outstanding Quality! I ordered a custom 3D model and the level of detail blew me away. The artist was super communicative and delivered exactly what I envisioned. Will definitely return for more projects!'
  },
  {
    id: 2,
    name: 'Sarah L.',
    image: '/customer-2.jpg',
    rating: 5,
    text: 'Amazing 2D Artwork! The 2D full-body illustration I received was vibrant, expressive, and beautifully crafted. RS Shop truly delivers premium art with passion and professionalism.'
  },
  {
    id: 3,
    name: 'David K.',
    image: '/customer-3.jpg',
    rating: 5,
    text: 'Perfect for Content Creators! As a streamer, I needed overlays and emotes. RS Shop nailed both the static and animated versions, and they look super polished on my channel. Highly recommend!'
  },
  {
    id: 4,
    name: 'Emily T.',
    image: '/customer-4.jpg',
    rating: 5,
    text: 'Professional and Friendly! The team was easy to work with, quick to respond, and very open to revisions. My custom logo came out sleek and modern. Worth every penny!'
  },
];

function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  const whatsappLink = `https://wa.me/13073964129?text=Hi, I'm interested in your services!`;

  return (
    <div className="min-h-screen bg-dark text-white overflow-x-hidden">
      {/* Top Bar */}
      <div className="bg-secondary/50 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
          <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
            <div className="flex items-center gap-4">
              <a href="tel:+13073964129" className="flex items-center gap-1.5 text-gray-300 hover:text-primary transition-colors">
                <Phone className="w-4 h-4" />
                <span>+1 (307) 396-4129</span>
              </a>
              <a href="mailto:retailershop0744@outlook.com" className="flex items-center gap-1.5 text-gray-300 hover:text-primary transition-colors">
                <Mail className="w-4 h-4" />
                <span className="hidden sm:inline">retailershop0744@outlook.com</span>
              </a>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-gray-400 text-xs">Discord: Lunaluxe0744</span>
              <div className="flex items-center gap-2">
                <a href="https://discord.com" target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-full bg-white/5 hover:bg-primary/20 transition-colors">
                  <MessageCircle className="w-4 h-4 text-gray-300 hover:text-primary" />
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-full bg-white/5 hover:bg-primary/20 transition-colors">
                  <Instagram className="w-4 h-4 text-gray-300 hover:text-primary" />
                </a>
                <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-full bg-white/5 hover:bg-primary/20 transition-colors">
                  <Phone className="w-4 h-4 text-gray-300 hover:text-primary" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className={`sticky top-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-dark/95 backdrop-blur-lg shadow-lg' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <a href="#" className="flex items-center gap-2">
              <img src="/logo.png" alt="RS Shop" className="h-10 w-auto" />
              <span className="font-display text-xl hidden sm:block">RS Shop</span>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-6">
              <button onClick={() => scrollToSection('home')} className="text-sm text-gray-300 hover:text-primary transition-colors">Home</button>
              <button onClick={() => scrollToSection('categories')} className="text-sm text-gray-300 hover:text-primary transition-colors">Categories</button>
              <button onClick={() => scrollToSection('products-2d')} className="text-sm text-gray-300 hover:text-primary transition-colors">2D Art</button>
              <button onClick={() => scrollToSection('products-3d')} className="text-sm text-gray-300 hover:text-primary transition-colors">3D Models</button>
              <button onClick={() => scrollToSection('products-covers')} className="text-sm text-gray-300 hover:text-primary transition-colors">Banners</button>
              <button onClick={() => scrollToSection('products-logos')} className="text-sm text-gray-300 hover:text-primary transition-colors">Logos</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-sm text-gray-300 hover:text-primary transition-colors">Reviews</button>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <ShoppingCart className="w-5 h-5" />
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary text-[10px] rounded-full flex items-center justify-center">0</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-dark border-white/10">
                  <DialogHeader>
                    <DialogTitle>Shopping Cart</DialogTitle>
                  </DialogHeader>
                  <div className="py-8 text-center text-gray-400">
                    <ShoppingCart className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Your cart is empty</p>
                    <p className="text-sm mt-2">Contact us on WhatsApp to order!</p>
                  </div>
                </DialogContent>
              </Dialog>
              
              {/* Mobile Menu Button */}
              <Button 
                variant="ghost" 
                size="icon" 
                className="lg:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-dark/95 backdrop-blur-lg border-t border-white/10">
            <div className="px-4 py-4 space-y-2">
              <button onClick={() => scrollToSection('home')} className="block w-full text-left py-2 text-gray-300 hover:text-primary">Home</button>
              <button onClick={() => scrollToSection('categories')} className="block w-full text-left py-2 text-gray-300 hover:text-primary">Categories</button>
              <button onClick={() => scrollToSection('products-2d')} className="block w-full text-left py-2 text-gray-300 hover:text-primary">2D Art</button>
              <button onClick={() => scrollToSection('products-3d')} className="block w-full text-left py-2 text-gray-300 hover:text-primary">3D Models</button>
              <button onClick={() => scrollToSection('products-covers')} className="block w-full text-left py-2 text-gray-300 hover:text-primary">Banners</button>
              <button onClick={() => scrollToSection('products-logos')} className="block w-full text-left py-2 text-gray-300 hover:text-primary">Logos</button>
              <button onClick={() => scrollToSection('testimonials')} className="block w-full text-left py-2 text-gray-300 hover:text-primary">Reviews</button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" ref={heroRef} className="relative min-h-[80vh] flex items-center">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img 
            src="/hero-bg.jpg" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-dark via-dark/50 to-transparent" />
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-2xl">
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl mb-6 leading-tight">
              <span className="text-gradient">Premium Digital</span>
              <br />
              <span className="text-white">Art & Design</span>
            </h1>
            <p className="text-lg sm:text-xl text-gray-300 mb-8 max-w-xl">
              Transform your vision into stunning reality. We create premium 2D artwork, 3D models, logos, and custom designs for gamers, streamers, and content creators.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                onClick={() => scrollToSection('categories')}
                className="bg-primary hover:bg-primary/90 text-white px-8 py-6 text-lg font-semibold"
              >
                Explore Categories
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button 
                  variant="outline" 
                  className="border-white/20 hover:bg-white/10 text-white px-8 py-6 text-lg"
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Contact Us
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section id="categories" className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl sm:text-5xl mb-4">
              <span className="text-gradient">Explore</span>{' '}
              <span className="text-white">Categories</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Discover our wide range of premium digital art services tailored for your creative needs
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6">
            {categories.map((category, index) => (
              <button
                key={category.id}
                onClick={() => scrollToSection(`products-${category.id}`)}
                className="group relative overflow-hidden rounded-2xl aspect-[3/4] cursor-pointer"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/50 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
                <div className="absolute inset-0 flex flex-col items-center justify-end p-4">
                  <category.icon className="w-8 h-8 text-primary mb-2" />
                  <h3 className="font-display text-lg text-white text-center">{category.name}</h3>
                </div>
                <div className="absolute inset-0 border-2 border-transparent group-hover:border-primary/50 rounded-2xl transition-colors" />
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Product Sections */}
      <ProductSection id="products-2d" title="2D Full Body" subtitle="Characters" products={products2D} />
      <ProductSection id="products-3d" title="Premium 3D" subtitle="Models" products={products3D} />
      <ProductSection id="products-covers" title="Covers and" subtitle="Banners" products={productsCovers} />
      <ProductSection id="products-logos" title="Custom Logo" subtitle="Designs" products={productsLogos} />
      <ProductSection id="products-pfp" title="Custom Profile" subtitle="Pictures" products={productsPFP} />

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl sm:text-5xl mb-4">
              <span className="text-white">Hear From Our</span>
              <br />
              <span className="text-gradient">Satisfied Customers</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonials.map((testimonial) => (
              <div 
                key={testimonial.id}
                className="glass rounded-2xl p-6 hover:shadow-glow transition-all duration-300"
              >
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-300 text-sm mb-6 line-clamp-4">{testimonial.text}</p>
                <div className="flex items-center gap-3">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-primary/30"
                  />
                  <div>
                    <h4 className="font-semibold text-white">{testimonial.name}</h4>
                    <p className="text-xs text-gray-400">Verified Customer</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary/30 border-t border-white/5 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <img src="/logo.png" alt="RS Shop" className="h-12 w-auto" />
                <span className="font-display text-xl">RS Shop</span>
              </div>
              <p className="text-gray-400 text-sm mb-4">
                Delivering premium 2D, 3D, and digital art solutions. Crafted with creativity, precision, and passion.
              </p>
              <div className="flex items-center gap-2">
                <CreditCard className="w-8 h-8 text-white" />
                <span className="text-sm text-gray-400">Secure Payments via Stripe</span>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-display text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><button onClick={() => scrollToSection('home')} className="text-gray-400 hover:text-primary text-sm transition-colors">Home</button></li>
                <li><button onClick={() => scrollToSection('categories')} className="text-gray-400 hover:text-primary text-sm transition-colors">Categories</button></li>
                <li><button onClick={() => scrollToSection('testimonials')} className="text-gray-400 hover:text-primary text-sm transition-colors">Reviews</button></li>
              </ul>
            </div>

            {/* Categories */}
            <div>
              <h3 className="font-display text-lg mb-4">Categories</h3>
              <ul className="space-y-2">
                <li><button onClick={() => scrollToSection('products-2d')} className="text-gray-400 hover:text-primary text-sm transition-colors">2D Full Body</button></li>
                <li><button onClick={() => scrollToSection('products-3d')} className="text-gray-400 hover:text-primary text-sm transition-colors">3D Models</button></li>
                <li><button onClick={() => scrollToSection('products-covers')} className="text-gray-400 hover:text-primary text-sm transition-colors">Covers & Banners</button></li>
                <li><button onClick={() => scrollToSection('products-logos')} className="text-gray-400 hover:text-primary text-sm transition-colors">Logos</button></li>
                <li><button onClick={() => scrollToSection('products-pfp')} className="text-gray-400 hover:text-primary text-sm transition-colors">Profile Pictures</button></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-display text-lg mb-4">Connect With Us</h3>
              <ul className="space-y-3">
                <li>
                  <a href="tel:+13073964129" className="flex items-center gap-2 text-gray-400 hover:text-primary text-sm transition-colors">
                    <Phone className="w-4 h-4" />
                    +1 (307) 396-4129
                  </a>
                </li>
                <li>
                  <a href="mailto:retailershop0744@outlook.com" className="flex items-center gap-2 text-gray-400 hover:text-primary text-sm transition-colors">
                    <Mail className="w-4 h-4" />
                    retailershop0744@outlook.com
                  </a>
                </li>
                <li className="flex items-center gap-2 text-gray-400 text-sm">
                  <MessageCircle className="w-4 h-4" />
                  Discord: Lunaluxe0744
                </li>
              </ul>
              <div className="flex items-center gap-3 mt-4">
                <a href="https://discord.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-white/5 hover:bg-primary/20 transition-colors">
                  <MessageCircle className="w-5 h-5" />
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-white/5 hover:bg-primary/20 transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="p-2 rounded-full bg-white/5 hover:bg-primary/20 transition-colors">
                  <Phone className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm">
              © 2025 RS Shop. All rights reserved.
            </p>
            <div className="flex items-center gap-2">
              <span className="text-gray-500 text-sm">We accept:</span>
              <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-lg">
                <CreditCard className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Stripe</span>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      <a 
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
      >
        <Phone className="w-6 h-6" />
      </a>
    </div>
  );
}

// Product Section Component
interface Product {
  id: number;
  name: string;
  category: string;
  image: string;
  price: string;
}

interface ProductSectionProps {
  id: string;
  title: string;
  subtitle: string;
  products: Product[];
}

function ProductSection({ id, title, subtitle, products }: ProductSectionProps) {
  const whatsappLink = `https://wa.me/13073964129?text=Hi, I'm interested in: `;

  return (
    <section id={id} className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-12">
          <div>
            <h2 className="font-display text-4xl sm:text-5xl">
              <span className="text-white">{title}</span>
              <br />
              <span className="text-gradient">{subtitle}</span>
            </h2>
          </div>
          <a 
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10">
              View All
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6">
          {products.map((product, index) => (
            <div 
              key={product.id}
              className="group relative bg-secondary/20 rounded-xl overflow-hidden hover:shadow-glow transition-all duration-300"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="aspect-[3/4] overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-dark via-transparent to-transparent opacity-60" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="text-xs text-primary mb-1">{product.category}</p>
                <h3 className="font-semibold text-white text-sm mb-2 line-clamp-2">{product.name}</h3>
                <a 
                  href={`${whatsappLink}${encodeURIComponent(product.name)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button size="sm" className="w-full bg-primary/80 hover:bg-primary text-xs">
                    <MessageCircle className="w-3 h-3 mr-1" />
                    Ask Now
                  </Button>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default App;
